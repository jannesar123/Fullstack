import React from "react";

function Error() {
  return (
    <div className="container justify-content-center">
      <h1>Error</h1>
    </div>
  );
}

export default Error;